function e = vr(m,i)
% The ith coordinate vector e in the m-dimensional Euclidean space.
e = zeros(m,1);
e(i) = 1;